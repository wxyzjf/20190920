CREATE VIEW VW_PREORDER_INVOICE(
    INV_NUM,
    INV_DATE,
    CUST_NUM,
    SUBR_NUM,
    STAT,
    POS_SHOP_CD,
    D_VAILD_SHOP_CD,
    D_VAILD_SO_CD,
    SALESMAN_CD,
    POS_PROD_CD,
    PROD_GROUP,
    PROD_LONG_DESC,
    PROD_SHORT_DESC,
    SERIES,
    PRODUCT_NATURE,
    COLOR,
    PROD_DISPLAYORDER_1,
    PROD_DISPLAYORDER_2 ,
    QTY,
    PRICE_LIST,
    MKT_CD,
    ONLINE_INV_FLG,
    ECOMM_REF_ID,
    ECOMM_ORDER_ID,
    CREATE_TS,
    REFRESH_TS
) AS
SELECT a.INV_NUM,
       a.INV_DATE,
       a.CUST_NUM,
       a.SUBR_NUM,
       a.STAT,
       a.POS_SHOP_CD,
       CASE WHEN a.POS_SHOP_CD = b.UNIT_CD THEN 'Y' END AS D_VAILD_SHOP_CD,
       CASE WHEN a.POS_SHOP_CD = b.XX_UNIT_CD THEN 'Y' END AS D_VAILD_SO_CD,
       a.SALESMAN_CD,
       a.POS_PROD_CD,
       nvl(c.PROD_GROUP,' '),
       nvl(c.PROD_LONG_DESC,' '),
       nvl(c.PROD_SHORT_DESC,' '),
       nvl(c.SERIES,' '),
       nvl(c.PRODUCT_NATURE,' '),
       nvl(c.COLOR,' '),
       nvl(c.DISPLAYORDER_1,0) AS PROD_DISPLAYORDER_1,
       nvl(c.DISPLAYORDER_2,0) AS PROD_DISPLAYORDER_2 ,
       a.QTY,
       a.PRICE_LIST,
       a.MKT_CD,
       a.ONLINE_INV_FLG,
       a.ECOMM_REF_ID,
       a.ECOMM_ORDER_ID,
       a.CREATE_TS,
       a.REFRESH_TS
  FROM PRD_ADW.POS_INV_HDR_FM_2NOV a
  LEFT OUTER JOIN (SELECT UNIT_CD AS UNIT_CD, 'XX' || UNIT_CD AS XX_UNIT_CD
               FROM PRD_ADW.RBD_UNIT
              WHERE DAILY_SALES_SMS = 'Y'
              GROUP BY UNIT_CD) b
         ON a.POS_SHOP_CD = b.UNIT_CD OR a.POS_SHOP_CD = b.XX_UNIT_CD
  LEFT OUTER JOIN (SELECT tmpa.PROD_CD,
                          tmpa.PROD_GROUP,
                          tmpa.PROD_LONG_DESC,
                          tmpa.PROD_SHORT_DESC,
                          tmpa.SERIES,
                          tmpa.PRODUCT_NATURE,
                          tmpa.COLOR,
                          tmpa.DISPLAYORDER_1,
                          tmpa.DISPLAYORDER_2
                     FROM MIG_ADW.PREORDER_PROD_REF tmpa
                    INNER JOIN (SELECT PROD_CD, MAX (EFF_END_DATE) EFF_END_DATE 
                                  FROM MIG_ADW.PREORDER_PROD_REF 
                                 GROUP BY PROD_CD) tmpb
                            ON tmpa.PROD_CD = tmpb.PROD_CD AND tmpa.EFF_END_DATE = tmpb.EFF_END_DATE
                   ) c ON a.POS_PROD_CD = c.PROD_CD
 WHERE INV_DATE <= CURRENT_DATE - 1 
   AND NOT EXISTS (
            SELECT 'X' 
              FROM PRD_ADW.POS_RET_HDR_FM_2NOV 
             WHERE TRX_DATE <= SYSDATE - 1 
               AND INV_NUM = a.INV_NUM);
               
GRANT SELECT ON MIG_BIZ_SUMM.VW_PREORDER_INVOICE TO MIG_ADW;

GRANT SELECT ON MIG_BIZ_SUMM.VW_PREORDER_INVOICE TO ADWBAT_READ;


