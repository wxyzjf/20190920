CREATE GLOBAL TEMPORARY TABLE MIG_ADW.B_PREORDER_INV_DETAILS_001_T
(
   INV_NUM            VARCHAR2(30 BYTE)             DEFAULT ' '                   NOT NULL,
   INV_DATE           DATE                          DEFAULT to_date('19000101','yyyymmdd') NOT NULL,
   CUST_NUM           VARCHAR2(20 BYTE)             DEFAULT ' '                   NOT NULL,
   SUBR_NUM           VARCHAR2(20 BYTE)             DEFAULT ' '                   NOT NULL,
   STAT               VARCHAR2(1 BYTE)              DEFAULT ' '                   NOT NULL,
   POS_SHOP_CD        VARCHAR2(50 BYTE)             DEFAULT ' '                   NOT NULL,
   D_Vaild_Shop_Cd    VARCHAR2(50 BYTE)              DEFAULT ' '                   NOT NULL,
   D_Vaild_SO_Cd      VARCHAR2(50 BYTE)              DEFAULT ' '                   NOT NULL,
   SALESMAN_CD        VARCHAR2(25 BYTE)             DEFAULT ' '                   NOT NULL,
   POS_PROD_CD        VARCHAR2(40 BYTE)             DEFAULT ' '                   NOT NULL,
   PROD_GROUP         VARCHAR2(100 BYTE)            DEFAULT ' '                   NOT NULL,
   PROD_LONG_DESC     VARCHAR2(100 BYTE)            DEFAULT ' '                   NOT NULL,
   PROD_SHORT_DESC    VARCHAR2(100 BYTE)            DEFAULT ' '                   NOT NULL,
   SERIES             VARCHAR2(20 BYTE)             DEFAULT ' '                   NOT NULL,
   PRODUCT_NATURE     VARCHAR2(20 BYTE)             DEFAULT ' '                   NOT NULL,
   COLOR              VARCHAR2(20 BYTE)             DEFAULT ' '                   NOT NULL,
   DISPLAYORDER_1     NUMBER(18)                    DEFAULT 0                     NOT NULL,
   DISPLAYORDER_2     NUMBER(18)                    DEFAULT 0                     NOT NULL,
   QTY                NUMBER(18,5)                  DEFAULT 0                     NOT NULL,
   MKT_CD             VARCHAR2(100 BYTE)             DEFAULT ' '                   NOT NULL,
   PRICE_LIST         VARCHAR2(100 BYTE)              DEFAULT ' '                   NOT NULL,
   ONLINE_INV_FLG     VARCHAR2(1 BYTE)              DEFAULT ' '                   NOT NULL,
   ECOMM_REF_ID       VARCHAR2(20 BYTE)             DEFAULT ' '                   NOT NULL,
   ECOMM_ORDER_ID     VARCHAR2(40 BYTE)             DEFAULT ' '                   NOT NULL,
   CREATE_TS          TIMESTAMP(0)                  DEFAULT TO_TIMESTAMP('1900-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') NOT NULL,
   REFRESH_TS         TIMESTAMP(0)                  DEFAULT TO_TIMESTAMP('1900-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') NOT NULL
) ON COMMIT DELETE ROWS;
GRANT SELECT ON MIG_ADW.B_PREORDER_INV_DETAILS_001_T TO ADWBAT_READ;
GRANT SELECT ON MIG_ADW.B_PREORDER_INV_DETAILS_001_T TO PRD_TMP_READ;
GRANT DELETE, INSERT, SELECT, UPDATE ON MIG_ADW.B_PREORDER_INV_DETAILS_001_T TO MIG_SUP_ROLE;
GRANT DELETE, INSERT, SELECT, UPDATE ON MIG_ADW.B_PREORDER_INV_DETAILS_001_T TO PRD_TMP_READ_WRITE;
GRANT SELECT ON MIG_ADW.B_PREORDER_INV_DETAILS_001_T TO MIG_BIZ_SUMM WITH GRANT OPTION;
GRANT SELECT ON MIG_ADW.B_PREORDER_INV_DETAILS_001_T TO ADWBAT_READ;
GRANT SELECT ON MIG_ADW.B_PREORDER_INV_DETAILS_001_T TO PRD_ADW_READ;
GRANT DELETE, INSERT, SELECT, UPDATE ON MIG_ADW.B_PREORDER_INV_DETAILS_001_T TO PRD_ADW_READ_WRITE;
GRANT SELECT ON MIG_ADW.B_PREORDER_INV_DETAILS_001_T TO PRD_BIZ_SUMM_VW;






