/opt/etl/prd/etl/APP/ADW/B_PREORDER_INV_DETAILS/bin>  cat b_preorder_inv_details0010.pl 
######################################################
#   $Header: /CVSROOT/SmarTone-Vodafone/Code/ETL/APP/ADW/B_BLACK_LIST_CUST/bin/b_black_list_cust0010.pl,v 1.1 2005/12/14 01:03:55 MichaelNg Exp $
#   Purpose:
#
#
######################################################


my $ETLVAR = $ENV{"AUTO_ETLVAR"};require $ETLVAR;
#*#
my $MASTER_TABLE = ""; #Please input the final target ADW table name here

#*#
my $TARGET_DB; 
my $TARGET_DB2;
my $TARGET_DB3;
my $TMP_DB;

sub initParam{
    $TARGET_DB = ${etlvar::MIGDB};
        $TARGET_DB2 = ${etlvar::MIGDB};
        $TARGET_DB3 = "MIG_BIZ_SUMM";
        $TMP_DB = ${etlvar::MIGDB};
}
#*#

sub runSQLPLUS{
    my $rc = open(SQLPLUS, "| sqlplus /\@${etlvar::TDDSN}");
    unless ($rc){
        print "Cound not invoke SQLPLUS commAND\n";
        return -1;
    }
    
#*#
#my $SQLCMD_FILE="/opt/etl/prd/etl/APP/ADW/B_PREORDER_INV_DETAILS/bin/b_preorder_inv_details0010.sql";
#  open SQLPLUS, ">" . $SQLCMD_FILE || die "Cannot open file" ;
#*#



    print SQLPLUS<<ENDOFINPUT;

      ${etlvar::LOGON_TD}
      ${etlvar::SET_MAXERR}
      ${etlvar::SET_ERRLVL_1}
      ${etlvar::SET_ERRLVL_2}

#*#
--Please type your SQL statement here
alter session force parallel query parallel 30;
alter session force parallel dml parallel 30;

set define on;
define tx_date=to_date('${etlvar::TXDATE}','YYYY-MM-DD');
#*#

#*#
--EXECUTE ${etlvar::UTLDB}.ETL_UTILITY.truncate_tbl2(P_schema_tbl_name=>'${etlvar::ADWDB}.PREORDER_INV_DETAILS');
EXECUTE ${etlvar::UTLDB}.ETL_UTILITY.truncate_tbl2(P_schema_tbl_name=>'MIG_ADW.PREORDER_INV_DETAILS');

#*#
--SET SERVEROUTPUT ON;
#*#
SET SERVEROUTPUT ON;
DECLARE
----------------CURSOR 1
    CURSOR reg_details_cur
    IS
    select a.Inv_Num,a.Inv_Date,a.Cust_Num,a.Subr_Num,a.STAT,a.Pos_Shop_Cd,a.D_Vaild_Shop_Cd,
           a.D_Vaild_SO_Cd,a.Salesman_Cd,a.Pos_Prod_Cd,a.Prod_Group,a.Prod_Long_Desc,a.Prod_Short_Desc,
           a.Series,a.Product_Nature,a.Color,a.Prod_DisplayOrder_1,a.Prod_DisplayOrder_2,a.Qty,a.Mkt_Cd,
           a.Price_List,a.Online_Inv_Flg,a.Ecomm_Ref_ID,a.Ecomm_Order_ID,a.Create_Ts,a.Refresh_Ts
      from $TARGET_DB3.VW_PREORDER_INVOICE a  #*#
            ;
        
-------------------      
    v_cnt number(18);
    target_tbl $TARGET_DB2.PREORDER_INV_DETAILS%rowtype;#*#

--sub procedure start
    PROCEDURE CHECK_CONDITION 
    (   
        p_key_tbl VARCHAR2,
        p_key_col VARCHAR2,
        p_prod_group IN VARCHAR2,
        p_prod_cd IN VARCHAR2,
        v_result_cd OUT varchar2,
        v_result_cd_order OUT number
    )
    IS
    CURSOR logic_ref_cur (v_prod_group varchar,v_prod_cd varchar) 
        IS
        SELECT ASSIGN_ORDER,ASSIGN_VAL,COND1_COL,COND1_VAL,COND2_COL,COND2_VAL,
               COND3_COL,COND3_VAL,COND4_COL,COND4_VAL,COND5_COL,COND5_VAL,
               COND6_COL,COND6_VAL,DISPLAYORDER,EFF_END_DATE,EFF_START_DATE,
               ELSE_VAL,KEY_COL,KEY_TBL,PROD_CD,PROD_GROUP
          FROM $TARGET_DB.PREORDER_LOGIC_REF#*#
         WHERE PROD_GROUP = v_prod_group
           AND (PROD_CD = v_prod_cd OR PROD_CD = 'ANY')
           AND KEY_TBL = p_key_tbl
           AND KEY_COL = p_key_col
           AND (&tx_date - 1) between EFF_START_DATE and EFF_END_DATE
        ORDER BY PROD_GROUP,PROD_CD,Assign_Order;#*#
        
        
        
        v_tmp_sql varchar2(10000);
        
        v_prod_cd_sql varchar2(9000);
        v_prod_cd_order_sql varchar2(9000);
        
        v_final_sql varchar2(20000);
        
        v_last_prod_cd varchar2(200);
        
        
    BEGIN
        v_result_cd := ' ';
        v_result_cd_order := 999;
        
        v_prod_cd_sql := 'case when 1=2 then ''''';
        v_prod_cd_order_sql := 'case when 1=2 then 999';
        FOR logicRef IN logic_ref_cur(p_prod_group, p_prod_cd)
        LOOP
            v_tmp_sql := ' when 1=1';
            IF(logicRef.COND1_COL != ' ') THEN
                v_tmp_sql := v_tmp_sql||' and '||logicRef.COND1_COL||' '||logicRef.COND1_VAL;
            END IF;
            IF(logicRef.COND2_COL != ' ') THEN
                v_tmp_sql := v_tmp_sql||' and '||logicRef.COND2_COL||' '||logicRef.COND2_VAL;
            END IF;
            IF(logicRef.COND3_COL != ' ') THEN
                v_tmp_sql := v_tmp_sql||' and '||logicRef.COND3_COL||' '||logicRef.COND3_VAL;
            END IF;
            IF(logicRef.COND4_COL != ' ') THEN
                v_tmp_sql := v_tmp_sql||' and '||logicRef.COND4_COL||' '||logicRef.COND4_VAL;
            END IF;
            IF(logicRef.COND5_COL != ' ') THEN
                v_tmp_sql := v_tmp_sql||' and '||logicRef.COND5_COL||' '||logicRef.COND5_VAL;
            END IF;
            IF(logicRef.COND6_COL != ' ') THEN
                v_tmp_sql := v_tmp_sql||' and '||logicRef.COND6_COL||' '||logicRef.COND6_VAL;
            END IF;
            
            v_prod_cd_sql := v_prod_cd_sql||v_tmp_sql||' then '||REGEXP_SUBSTR(logicRef.ASSIGN_VAL,'^''.*''\$|\\w*\$');
            v_prod_cd_order_sql := v_prod_cd_order_sql||v_tmp_sql||' then '||logicRef.DISPLAYORDER;
            v_last_prod_cd := logicRef.ELSE_VAL;
        END LOOP;
        v_prod_cd_sql := v_prod_cd_sql||' else '||NVL(REGEXP_SUBSTR(v_last_prod_cd,'^''.*''\$|\\w*\$'),''' ''')||' end as d_result_cd, '; 
        v_prod_cd_order_sql := v_prod_cd_order_sql||' else 999 end as result_cd_order ';
        v_final_sql := 'SELECT '||v_prod_cd_sql||v_prod_cd_order_sql||' FROM $TMP_DB.B_PREORDER_INV_DETAILS_001_T';
        #*#
--        dbms_output.put_line(v_final_sql);
        --execute SQL
        execute immediate v_final_sql INTO v_result_cd,v_result_cd_order;

    END;
--sub procedure end

BEGIN
    v_cnt := 0;
    
    FOR detail IN reg_details_cur
    LOOP
        --insert into tmp table for match the request col
        delete from $TMP_DB.B_PREORDER_INV_DETAILS_001_T;#*#
        INSERT INTO $TMP_DB.B_PREORDER_INV_DETAILS_001_T(#*#
            Inv_Num,Inv_Date,Cust_Num,Subr_Num,STAT,Pos_Shop_Cd,D_Vaild_Shop_Cd,
            D_Vaild_SO_Cd,Salesman_Cd,Pos_Prod_Cd,Prod_Group,Prod_Long_Desc,Prod_Short_Desc,
            Series,Product_Nature,Color,DISPLAYORDER_1,DISPLAYORDER_2,Qty,Mkt_Cd,
            Price_List,Online_Inv_Flg,Ecomm_Ref_ID,Ecomm_Order_ID,Create_Ts,Refresh_Ts
        )VALUES(
            detail.Inv_Num,detail.Inv_Date,detail.Cust_Num,detail.Subr_Num,detail.STAT,detail.Pos_Shop_Cd,NVL(detail.D_Vaild_Shop_Cd,' '),
            NVL(detail.D_Vaild_SO_Cd,' '),detail.Salesman_Cd,detail.Pos_Prod_Cd,detail.Prod_Group,detail.Prod_Long_Desc,detail.Prod_Short_Desc,
            detail.Series,detail.Product_Nature,detail.Color,detail.Prod_DisplayOrder_1,detail.Prod_DisplayOrder_2,detail.Qty,detail.Mkt_Cd,
            detail.Price_List,detail.Online_Inv_Flg,detail.Ecomm_Ref_ID,detail.Ecomm_Order_ID,detail.Create_Ts,detail.Refresh_Ts
        );
        
        CHECK_CONDITION('PRD_BIZ_SUMM.PREORDER_INV_DETAILS','D_CUST_NATURE',detail.PROD_GROUP,detail.Pos_Prod_Cd,target_tbl.D_CUST_NATURE,target_tbl.D_Cust_Nature_Order);
        CHECK_CONDITION('PRD_BIZ_SUMM.PREORDER_INV_DETAILS','D_Prepaid_Ind',detail.PROD_GROUP,detail.Pos_Prod_Cd,target_tbl.D_Prepaid_Ind,target_tbl.D_Prepaid_Ind_Order);
        
        
        
        insert into $TARGET_DB2.PREORDER_INV_DETAILS (#*#
             INV_NUM,INV_DATE,CUST_NUM,SUBR_NUM,STAT,POS_SHOP_CD,D_VAILD_SHOP_CD,D_VAILD_SO_CD,SALESMAN_CD,
             POS_PROD_CD,PROD_GROUP,PROD_LONG_DESC,PROD_SHORT_DESC,SERIES,PRODUCT_NATURE,COLOR,PROD_DISPLAYORDER_1,
             PROD_DISPLAYORDER_2,QTY,MKT_CD,PRICE_LIST,ONLINE_INV_FLG,ECOMM_REF_ID,ECOMM_ORDER_ID,CREATE_TS,REFRESH_TS,
             
             D_Cust_Nature,D_Cust_Nature_Order,D_Prepaid_Ind,D_Prepaid_Ind_Order
        )values(
            detail.Inv_Num,detail.Inv_Date,detail.Cust_Num,detail.Subr_Num,detail.STAT,detail.Pos_Shop_Cd,NVL(detail.D_Vaild_Shop_Cd,' '),
            NVL(detail.D_Vaild_SO_Cd,' '),detail.Salesman_Cd,detail.Pos_Prod_Cd,detail.Prod_Group,detail.Prod_Long_Desc,detail.Prod_Short_Desc,
            detail.Series,detail.Product_Nature,detail.Color,detail.Prod_DisplayOrder_1,detail.Prod_DisplayOrder_2,detail.Qty,detail.Mkt_Cd,
            detail.Price_List,detail.Online_Inv_Flg,detail.Ecomm_Ref_ID,detail.Ecomm_Order_ID,detail.Create_Ts,detail.Refresh_Ts,
            
            target_tbl.D_Cust_Nature,target_tbl.D_Cust_Nature_Order,
            target_tbl.D_Prepaid_Ind,target_tbl.D_Prepaid_Ind_Order
        );
        v_cnt := v_cnt+1;
        IF(mod(v_cnt,5000) = 0) THEN
           commit;
        END IF;
--        exit;
    END LOOP;
    commit;
   
#*#
EXCEPTION WHEN OTHERS THEN
        dbms_output.put_line('SQLCODE:' || SQLCODE);
        dbms_output.put_line('SQLERRM:' || SQLERRM);
        raise_application_error(-20001,'Error - '||SQLCODE||' -Messge '||SQLERRM);
        ROLLBACK;
#*#
    
END;

/
#*#
exit;

ENDOFINPUT

    close(SQLPLUS);
    my $RET_CODE = $? >> 8;
    #*#
#    my $RET_CODE = system("sqlplus /\@${etlvar::TDDSN} \@$SQLCMD_FILE");
    if ($RET_CODE != 0){
        return 1;
    }else{
        return 0;
    }
}


#We need to have variable input for the program to start
if ($#ARGV < 0){
    print("Syntax : perl <Script Name> <System Name>_<Job Name>_<TXDATE>.dir>\n");
    print("Example: perl b_cust_info0010.pl adw_b_cust_info_20051010.dir\n");
    exit(1);
}


#Call the function we want to run
open(STDERR, ">&STDOUT");

my $pre = etlvar::preProcess($ARGV[0]);
my $rc = etlvar::getTXDate($MASTER_TABLE);


my $ret = runSQLPLUS();
#*#
my $ret = initParam();
if ($ret == 0){
        $ret = runSQLPLUS();
}
if ($ret != 0){
    exit 2;
}
#*#


my $post = etlvar::postProcess();

exit($ret);



