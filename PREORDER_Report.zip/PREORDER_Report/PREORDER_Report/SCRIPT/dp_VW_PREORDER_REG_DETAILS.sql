CREATE VIEW PRD_BIZ_SUMM.VW_PREORDER_REG_DETAILS (
    CASE_ID,
    STATUS,
    ORDER_DATE,
    ORDER_TIME,
    PROD_CD,
    PROD_GROUP,
    PROD_LONG_DESC,
    PROD_SHORT_DESC,
    SERIES,
    PRODUCT_NATURE,
    COLOR,
    PROD_DISPLAYORDER_1,
    PROD_DISPLAYORDER_2,
    REG_INV_NUM,
    REG_INV_DATE,
    REG_INV_TIME,
    POS_INV_NUM,
    POS_INV_DATE,
    POS_INV_TIME,
    PORDER_OVERDUE_GRACE_DAY,
    VOID_DATE,
    VOID_TIME,
    ORDER_CHANNEL,
    CUST_GROUP, 
    PREPAID_IND,
    OVERDUE_DATE,
    HKID_BR,
    HSO_IND,
    ANY_COLOUR_IND,
    ORIGINAL_PRODUCT,
    ORG_PROD_GROUP,
    ORG_PROD_LONG_DESC,
    ORG_PROD_SHORT_DESC,
    ORG_SERIES,
    ORG_PRODUCT_NATURE,
    ORG_COLOR,
    ORG_PROD_DISPLAYORDER_1,
    ORG_PROD_DISPLAYORDER_2,
    CREATE_DATE,
    ORIGINAL_SUBMIT_DATE,
    CUST_NUM
) AS
SELECT a.CASE_ID,
       a.STATUS,
       a.ORDER_DATE,
       a.ORDER_TIME,
       a.PROD_CD,
       nvl(c.PROD_GROUP,' '),
       nvl(c.PROD_LONG_DESC,' '),
       nvl(c.PROD_SHORT_DESC,' '),
       nvl(c.SERIES,' '),
       nvl(c.PRODUCT_NATURE,' '),
       nvl(c.COLOR,' '),
       nvl(c.DISPLAYORDER_1,0) AS PROD_DISPLAYORDER_1,
       nvl(c.DISPLAYORDER_2,0) AS PROD_DISPLAYORDER_2,
       a.INV_NUM AS REG_INV_NUM,
       a.INV_DATE AS REG_INV_DATE,
       a.INV_TIME AS REG_INV_TIME,
       nvl(b.INV_NUM,' ') AS POS_INV_NUM,
       nvl(b.TRX_DATE,date'2999-12-31') AS POS_INV_DATE,
       nvl(b.TRX_TIME,0) AS POS_INV_TIME,
       a.PORDER_OVERDUE_GRACE_DAY,
       a.VOID_DATE,
       a.VOID_TIME,
       a.ORDER_CHANNEL,
       a.CUST_GROUP,
       a.PREPAID_IND,
       a.OVERDUE_DATE,
       a.HKID_BR,
       a.HSO_IND,
       a.ANY_COLOUR_IND,
       a.ORIGINAL_PRODUCT,
       nvl(d.PROD_GROUP,' ') AS ORG_PROD_GROUP,
       nvl(d.PROD_LONG_DESC,' ')  AS ORG_PROD_LONG_DESC,
       nvl(d.PROD_SHORT_DESC,' ')  AS ORG_PROD_SHORT_DESC,
       nvl(d.SERIES,' ')  AS ORG_SERIES,
       nvl(d.PRODUCT_NATURE,' ')  AS ORG_PRODUCT_NATURE,
       nvl(d.COLOR,' ')  AS ORG_COLOR,
       nvl(d.DISPLAYORDER_1,0)  AS ORG_PROD_DISPLAYORDER_1,
       nvl(d.DISPLAYORDER_2,0)  AS ORG_PROD_DISPLAYORDER_2,
       TRUNC(CAST(a.CREATE_TS AS DATE),'DD') CREATE_DATE,
       a.ORIGINAL_SUBMIT_DATE,
       a.CUST_NUM
  FROM PRD_ADW.POS_IPHONE_REG a
  LEFT OUTER JOIN PRD_ADW.POS_RET_HDR_FM_2NOV b ON a.INV_NUM = b.INV_NUM AND TRX_DATE <= SYSDATE - 1
  LEFT OUTER JOIN (SELECT tmpa.PROD_CD,
                          tmpa.PROD_GROUP,
                          tmpa.PROD_LONG_DESC,
                          tmpa.PROD_SHORT_DESC,
                          tmpa.SERIES,
                          tmpa.PRODUCT_NATURE,
                          tmpa.COLOR,
                          tmpa.DISPLAYORDER_1,
                          tmpa.DISPLAYORDER_2
                     FROM MIG_ADW.PREORDER_PROD_REF tmpa
                    INNER JOIN (SELECT PROD_CD, MAX (EFF_END_DATE) EFF_END_DATE
                                  FROM MIG_ADW.PREORDER_PROD_REF
                                 GROUP BY PROD_CD) tmpb
                       ON tmpa.PROD_CD = tmpb.PROD_CD AND tmpa.EFF_END_DATE = tmpb.EFF_END_DATE
                    ) c ON a.PROD_CD = c.PROD_CD
  LEFT OUTER JOIN (SELECT tmpa.PROD_CD,
                          tmpa.PROD_GROUP,
                          tmpa.PROD_LONG_DESC,
                          tmpa.PROD_SHORT_DESC,
                          tmpa.SERIES,
                          tmpa.PRODUCT_NATURE,
                          tmpa.COLOR,
                          tmpa.DISPLAYORDER_1,
                          tmpa.DISPLAYORDER_2
                     FROM MIG_ADW.PREORDER_PROD_REF tmpa
                    INNER JOIN (SELECT PROD_CD, MAX (EFF_END_DATE) EFF_END_DATE
                                  FROM MIG_ADW.PREORDER_PROD_REF
                                 GROUP BY PROD_CD) tmpb
                            ON tmpa.PROD_CD = tmpb.PROD_CD AND tmpa.EFF_END_DATE = tmpb.EFF_END_DATE
                        ) d ON a.ORIGINAL_PRODUCT = d.PROD_CD
 WHERE a.ORIGINAL_SUBMIT_DATE <= SYSDATE - 1;
 
 
GRANT SELECT ON PRD_BIZ_SUMM.VW_PREORDER_REG_DETAILS TO ADWBAT_READ;

GRANT DELETE, INSERT, SELECT, UPDATE ON PRD_BIZ_SUMM.VW_PREORDER_REG_DETAILS TO MIG_SUP_ROLE;

GRANT SELECT ON PRD_BIZ_SUMM.VW_PREORDER_REG_DETAILS TO PRD_ADW_READ;

GRANT DELETE, INSERT, SELECT, UPDATE ON PRD_BIZ_SUMM.VW_PREORDER_REG_DETAILS TO PRD_ADW_READ_WRITE;

GRANT SELECT ON PRD_BIZ_SUMM.VW_PREORDER_REG_DETAILS TO PRD_TMP_READ;
