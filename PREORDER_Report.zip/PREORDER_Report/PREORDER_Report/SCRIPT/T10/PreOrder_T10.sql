--SET SERVEROUTPUT ON;
DECLARE
----------------CURSOR 1
    CURSOR reg_details_cur
    IS
    select a.Inv_Num,a.Inv_Date,a.Cust_Num,a.Subr_Num,a.STAT,a.Pos_Shop_Cd,a.D_Vaild_Shop_Cd,
           a.D_Vaild_SO_Cd,a.Salesman_Cd,a.Pos_Prod_Cd,a.Prod_Group,a.Prod_Long_Desc,a.Prod_Short_Desc,
           a.Series,a.Product_Nature,a.Color,a.Prod_DisplayOrder_1,a.Prod_DisplayOrder_2,a.Qty,a.Mkt_Cd,
           a.Price_List,a.Online_Inv_Flg,a.Ecomm_Ref_ID,a.Ecomm_Order_ID,a.Create_Ts,a.Refresh_Ts
      from MIG_BIZ_SUMM.VW_PREORDER_INVOICE a
--      inner join MIG_ADW.PREORDER_PROD_REF b on (sysdate - 1) between b.EFF_START_DATE and b.EFF_END_DATE
--            and a.Pos_Prod_Cd = b.PROD_CD
            ;
        
-------------------      
    v_cnt number(18);
    target_tbl PREORDER_INV_DETAILS%rowtype;

--sub procedure start
--CHECK_CONDITION('PRD_BIZ_SUMM.PREORDER_REG_SUMM_DETAILS','D_PROD_CD',detail.PROD_GROUP,detail.PROD_CD,target_tbl.D_PROD_CD,target_tbl.D_PROD_CD_ORDER);

--CHECK_CONDITION('PRD_BIZ_SUMM.PREORDER_INV_DETAILS','D_Cust_Nature',detail.PROD_GROUP,detail.Pos_Prod_Cd,target_tbl.D_CUST_NATURE,target_tbl.D_Cust_Nature_Order);

    PROCEDURE CHECK_CONDITION 
    (   
        p_key_tbl VARCHAR2,
        p_key_col VARCHAR2,
        p_prod_group IN VARCHAR2,
        p_prod_cd IN VARCHAR2,
        v_result_cd OUT varchar2,
        v_result_cd_order OUT number
    )
    IS
    CURSOR logic_ref_cur (v_prod_group varchar,v_prod_cd varchar) 
        IS
        SELECT ASSIGN_ORDER,ASSIGN_VAL,COND1_COL,COND1_VAL,COND2_COL,COND2_VAL,
               COND3_COL,COND3_VAL,COND4_COL,COND4_VAL,COND5_COL,COND5_VAL,
               COND6_COL,COND6_VAL,DISPLAYORDER,EFF_END_DATE,EFF_START_DATE,
               ELSE_VAL,KEY_COL,KEY_TBL,PROD_CD,PROD_GROUP
          FROM MIG_ADW.PREORDER_LOGIC_REF
         WHERE PROD_GROUP = v_prod_group
           AND (PROD_CD = v_prod_cd OR PROD_CD = 'ANY')
           AND KEY_TBL = p_key_tbl
           AND KEY_COL = p_key_col
           AND (sysdate - 1) between EFF_START_DATE and EFF_END_DATE
        ORDER BY PROD_GROUP,PROD_CD,Assign_Order;
        
        
        
        v_tmp_sql varchar2(10000);
        
        v_prod_cd_sql varchar2(9000);
        v_prod_cd_order_sql varchar2(9000);
        
        v_final_sql varchar2(20000);
        
        v_last_prod_cd varchar2(200);
        
        
    BEGIN
        v_result_cd := ' ';
        v_result_cd_order := 999;
        
        v_prod_cd_sql := 'case when 1=2 then ''''';
        v_prod_cd_order_sql := 'case when 1=2 then 999';
        FOR logicRef IN logic_ref_cur(p_prod_group, p_prod_cd)
        LOOP
            v_tmp_sql := ' when 1=1';
            IF(logicRef.COND1_COL != ' ') THEN
                v_tmp_sql := v_tmp_sql||' and '||logicRef.COND1_COL||' '||logicRef.COND1_VAL;
            END IF;
            IF(logicRef.COND2_COL != ' ') THEN
                v_tmp_sql := v_tmp_sql||' and '||logicRef.COND2_COL||' '||logicRef.COND2_VAL;
            END IF;
            IF(logicRef.COND3_COL != ' ') THEN
                v_tmp_sql := v_tmp_sql||' and '||logicRef.COND3_COL||' '||logicRef.COND3_VAL;
            END IF;
            IF(logicRef.COND4_COL != ' ') THEN
                v_tmp_sql := v_tmp_sql||' and '||logicRef.COND4_COL||' '||logicRef.COND4_VAL;
            END IF;
            IF(logicRef.COND5_COL != ' ') THEN
                v_tmp_sql := v_tmp_sql||' and '||logicRef.COND5_COL||' '||logicRef.COND5_VAL;
            END IF;
            IF(logicRef.COND6_COL != ' ') THEN
                v_tmp_sql := v_tmp_sql||' and '||logicRef.COND6_COL||' '||logicRef.COND6_VAL;
            END IF;
            
            v_prod_cd_sql := v_prod_cd_sql||v_tmp_sql||' then '||REGEXP_SUBSTR(logicRef.ASSIGN_VAL,'^''.*''$|\w*$');
            v_prod_cd_order_sql := v_prod_cd_order_sql||v_tmp_sql||' then '||logicRef.DISPLAYORDER;
            v_last_prod_cd := logicRef.ELSE_VAL;
        END LOOP;
        v_prod_cd_sql := v_prod_cd_sql||' else '||NVL(REGEXP_SUBSTR(v_last_prod_cd,'^''.*''$|\w*$'),''' ''')||' end as d_result_cd, '; 
        v_prod_cd_order_sql := v_prod_cd_order_sql||' else 999 end as result_cd_order ';
        v_final_sql := 'SELECT '||v_prod_cd_sql||v_prod_cd_order_sql||' FROM PREORDER_INVOICE_T';-- M
        
--        dbms_output.put_line(v_final_sql);
        --execute SQL
        execute immediate v_final_sql INTO v_result_cd,v_result_cd_order;

    END;
--sub procedure end

BEGIN
    v_cnt := 0;
--    delete from MIG_ADW.PREORDER_INV_DETAILS where Pos_Prod_Cd in (select PROD_CD from MIG_ADW.PREORDER_PROD_REF where (sysdate - 1) between EFF_START_DATE and EFF_END_DATE);
    
    FOR detail IN reg_details_cur
    LOOP
        --insert into tmp table for match the request col
        delete from PREORDER_INVOICE_T;--M
        INSERT INTO PREORDER_INVOICE_T(--M
            Inv_Num,Inv_Date,Cust_Num,Subr_Num,STAT,Pos_Shop_Cd,D_Vaild_Shop_Cd,
            D_Vaild_SO_Cd,Salesman_Cd,Pos_Prod_Cd,Prod_Group,Prod_Long_Desc,Prod_Short_Desc,
            Series,Product_Nature,Color,DISPLAYORDER_1,DISPLAYORDER_2,Qty,Mkt_Cd,
            Price_List,Online_Inv_Flg,Ecomm_Ref_ID,Ecomm_Order_ID,Create_Ts,Refresh_Ts
        )VALUES(
            detail.Inv_Num,detail.Inv_Date,detail.Cust_Num,detail.Subr_Num,detail.STAT,detail.Pos_Shop_Cd,NVL(detail.D_Vaild_Shop_Cd,' '),
            NVL(detail.D_Vaild_SO_Cd,' '),detail.Salesman_Cd,detail.Pos_Prod_Cd,detail.Prod_Group,detail.Prod_Long_Desc,detail.Prod_Short_Desc,
            detail.Series,detail.Product_Nature,detail.Color,detail.Prod_DisplayOrder_1,detail.Prod_DisplayOrder_2,detail.Qty,detail.Mkt_Cd,
            detail.Price_List,detail.Online_Inv_Flg,detail.Ecomm_Ref_ID,detail.Ecomm_Order_ID,detail.Create_Ts,detail.Refresh_Ts
        );
        
        CHECK_CONDITION('PRD_BIZ_SUMM.PREORDER_INV_DETAILS','D_CUST_NATURE',detail.PROD_GROUP,detail.Pos_Prod_Cd,target_tbl.D_CUST_NATURE,target_tbl.D_Cust_Nature_Order);
        CHECK_CONDITION('PRD_BIZ_SUMM.PREORDER_INV_DETAILS','D_Prepaid_Ind',detail.PROD_GROUP,detail.Pos_Prod_Cd,target_tbl.D_Prepaid_Ind,target_tbl.D_Prepaid_Ind_Order);
        
        
        
        insert into MIG_ADW.PREORDER_INV_DETAILS (
             INV_NUM,INV_DATE,CUST_NUM,SUBR_NUM,STAT,POS_SHOP_CD,D_VAILD_SHOP_CD,D_VAILD_SO_CD,SALESMAN_CD,
             POS_PROD_CD,PROD_GROUP,PROD_LONG_DESC,PROD_SHORT_DESC,SERIES,PRODUCT_NATURE,COLOR,PROD_DISPLAYORDER_1,
             PROD_DISPLAYORDER_2,QTY,MKT_CD,PRICE_LIST,ONLINE_INV_FLG,ECOMM_REF_ID,ECOMM_ORDER_ID,CREATE_TS,REFRESH_TS,
             
             D_Cust_Nature,D_Cust_Nature_Order,D_Prepaid_Ind,D_Prepaid_Ind_Order
        )values(
            detail.Inv_Num,detail.Inv_Date,detail.Cust_Num,detail.Subr_Num,detail.STAT,detail.Pos_Shop_Cd,NVL(detail.D_Vaild_Shop_Cd,' '),
            NVL(detail.D_Vaild_SO_Cd,' '),detail.Salesman_Cd,detail.Pos_Prod_Cd,detail.Prod_Group,detail.Prod_Long_Desc,detail.Prod_Short_Desc,
            detail.Series,detail.Product_Nature,detail.Color,detail.Prod_DisplayOrder_1,detail.Prod_DisplayOrder_2,detail.Qty,detail.Mkt_Cd,
            detail.Price_List,detail.Online_Inv_Flg,detail.Ecomm_Ref_ID,detail.Ecomm_Order_ID,detail.Create_Ts,detail.Refresh_Ts,
            
            target_tbl.D_Cust_Nature,target_tbl.D_Cust_Nature_Order,
            target_tbl.D_Prepaid_Ind,target_tbl.D_Prepaid_Ind_Order
        );
        v_cnt := v_cnt+1;
        IF(mod(v_cnt,5000) = 0) THEN
           commit;
        END IF;
--        exit;
    END LOOP;
    commit;
    
END;