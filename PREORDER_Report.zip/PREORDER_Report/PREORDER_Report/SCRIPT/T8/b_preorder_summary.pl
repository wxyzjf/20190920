######################################################
#   $Header: 
#   Purpose:
#
#
######################################################


my $ETLVAR = $ENV{"AUTO_ETLVAR"};
require $ETLVAR;
my $TARGET_DB; 
my $TARGET_DB2;


sub initParam{
    $TARGET_DB = ${etlvar::MIGDB};
	$TARGET_DB2 = ${etlvar::MIGDB};
}


sub runSQLPLUS{
    my $rc = open(SQLPLUS, "| sqlplus /\@${etlvar::TDDSN}");
    unless ($rc){
        print "Cound not invoke SQLPLUS command\n";
        return -1;
    }

print SQLPLUS<<ENDOFINPUT;
        ${etlvar::LOGON_TD}
        ${etlvar::SET_MAXERR}
        ${etlvar::SET_ERRLVL_1}
        ${etlvar::SET_ERRLVL_2}

--Please type your SQL statement here
alter session force parallel query parallel 30;
alter session force parallel dml parallel 30;

set define on;
define tx_date=to_date('${etlvar::TXDATE}','YYYY-MM-DD');

SET SERVEROUTPUT ON;
DECLARE
    CURSOR cal_ref_cur
    IS
    select ID,FORMULA_FLG,FORMULA_OBJ1,FORMULA_OP,FORMULA_OBJ2,KEY_TBL,KEY_GROUP,PURPOSE,SALESNATURE,
           DISPLAYORDER1,DISPLAYORDER2,NUM,NUM_COND1_COL,NUM_COND1_VAL,NUM_COND2_COL,NUM_COND2_VAL,
           NUM_COND3_COL,NUM_COND3_VAL,NUM_COND4_COL,NUM_COND4_VAL,NUM_COND5_COL,NUM_COND5_VAL,
           NUM_G_ORDER_DATE,NUM_G_PROD_CD,NUM_G_SERIES,NUM_G_PRODUCT_NATURE,NUM_G_COLOR,
           NUM_G_CUST_NATURE,NUM_G_PROD_TYPE,NUM_G_HSO_DESC,NUM_G_CUST_SEGMENT,NUM_G_DUMMY1,NUM_G_DUMMY2
      from $TARGET_DB.PREORDER_SUMMARY_CAL_REF 
     where KEY_GROUP in (select PROD_GROUP from $TARGET_DB.PREORDER_PROD_REF where (&tx_date - 1) between EFF_START_DATE and EFF_END_DATE)
     order by CAL_ORDER;
     
    TYPE curtype IS REF CURSOR;
    cur1 curtype;
    sql_select_part varchar(5000);
    final_sql varchar(20000);
    
    target_tbl $TARGET_DB2.PREORDER_SUMMARY%rowType;
    v_cnt number(18);
BEGIN
    delete from $TARGET_DB2.PREORDER_SUMMARY where KEY_GROUP in 
        (select PROD_GROUP from $TARGET_DB.PREORDER_PROD_REF where (&tx_date - 1) between EFF_START_DATE and EFF_END_DATE);
    commit;
    v_cnt := 0;
    FOR cal_ref IN cal_ref_cur
    LOOP
        --detemine whether to division formula
        IF (cal_ref.FORMULA_FLG = 'N') THEN
            sql_select_part := 'SELECT max(D_DISPALYORDER_1),max(D_DISPALYORDER_2),max(D_CUST_NATURE_ORDER),
                    max(D_PROD_TYPE_ORDER),max(D_HSO_DESC_ORDER),max(D_CUST_SEGMENT_ORDER),'||cal_ref.NUM;
            final_sql := '';
            --where part
            IF(cal_ref.NUM_COND1_COL != ' ') THEN
                final_sql := final_sql||' AND '||cal_ref.NUM_COND1_COL||' '||cal_ref.NUM_COND1_VAL;
            END IF;
            IF(cal_ref.NUM_COND2_COL != ' ') THEN
                final_sql := final_sql||' AND '||cal_ref.NUM_COND2_COL||' '||cal_ref.NUM_COND2_VAL;
            END IF;
            IF(cal_ref.NUM_COND3_COL != ' ') THEN
                final_sql := final_sql||' AND '||cal_ref.NUM_COND3_COL||' '||cal_ref.NUM_COND3_VAL;
            END IF;
            IF(cal_ref.NUM_COND4_COL != ' ') THEN
                final_sql := final_sql||' AND '||cal_ref.NUM_COND4_COL||' '||cal_ref.NUM_COND4_VAL;
            END IF;
            IF(cal_ref.NUM_COND5_COL != ' ') THEN
                final_sql := final_sql||' AND '||cal_ref.NUM_COND5_COL||' '||cal_ref.NUM_COND5_VAL;
            END IF;
            
            --group by and select part
            final_sql := final_sql||' GROUP BY ';
            
            IF(cal_ref.NUM_G_ORDER_DATE != ' ' and cal_ref.NUM_G_ORDER_DATE != '''1900-01-01''' and cal_ref.NUM_G_ORDER_DATE != 'ANY') THEN
                sql_select_part := sql_select_part||', '||cal_ref.NUM_G_ORDER_DATE;
                final_sql := final_sql||cal_ref.NUM_G_ORDER_DATE||', ';
            ELSE
                sql_select_part := sql_select_part||', date''1900-01-01''';
            END IF;     
            IF(cal_ref.NUM_G_PROD_CD != ' ' and cal_ref.NUM_G_PROD_CD != 'ANY' ) THEN
                sql_select_part := sql_select_part||', '||cal_ref.NUM_G_PROD_CD;
                final_sql := final_sql||cal_ref.NUM_G_PROD_CD||', ';
            ELSE
                sql_select_part := sql_select_part||', '' ''';
            END IF;     
            IF(cal_ref.NUM_G_SERIES != ' ' and cal_ref.NUM_G_SERIES != 'ANY') THEN
                sql_select_part := sql_select_part||', '||cal_ref.NUM_G_SERIES;
                final_sql := final_sql||cal_ref.NUM_G_SERIES||', ';
            ELSE
                sql_select_part := sql_select_part||', '' ''';
            END IF;    
            IF(cal_ref.NUM_G_PRODUCT_NATURE != ' ' and cal_ref.NUM_G_PRODUCT_NATURE != 'ANY') THEN
                sql_select_part := sql_select_part||', '||cal_ref.NUM_G_PRODUCT_NATURE;
                final_sql := final_sql||cal_ref.NUM_G_PRODUCT_NATURE||', ';
            ELSE
                sql_select_part := sql_select_part||', '' ''';
            END IF;     
            IF(cal_ref.NUM_G_COLOR != ' ' and cal_ref.NUM_G_COLOR != 'ANY') THEN
                sql_select_part := sql_select_part||', '||cal_ref.NUM_G_COLOR;
                final_sql := final_sql||cal_ref.NUM_G_COLOR||', ';
            ELSE
                sql_select_part := sql_select_part||', '' ''';
            END IF;     
            IF(cal_ref.NUM_G_CUST_NATURE != ' ' and cal_ref.NUM_G_CUST_NATURE != 'ANY') THEN
                sql_select_part := sql_select_part||', '||cal_ref.NUM_G_CUST_NATURE;
                final_sql := final_sql||cal_ref.NUM_G_CUST_NATURE||', '; 
            ELSE
                sql_select_part := sql_select_part||', '' ''';
            END IF;        
            IF(cal_ref.NUM_G_PROD_TYPE != ' ' and cal_ref.NUM_G_PROD_TYPE != 'ANY') THEN
                sql_select_part := sql_select_part||', '||cal_ref.NUM_G_PROD_TYPE;
                final_sql := final_sql||cal_ref.NUM_G_PROD_TYPE||', ';
            ELSE
                sql_select_part := sql_select_part||', '' ''';
            END IF;     
            IF(cal_ref.NUM_G_HSO_DESC != ' ' and cal_ref.NUM_G_HSO_DESC != 'ANY') THEN
                sql_select_part := sql_select_part||', '||cal_ref.NUM_G_HSO_DESC;
                final_sql := final_sql||cal_ref.NUM_G_HSO_DESC||', ';
            ELSE
                sql_select_part := sql_select_part||', '' ''';
            END IF;         
            IF(cal_ref.NUM_G_CUST_SEGMENT != ' ' and cal_ref.NUM_G_CUST_SEGMENT != 'ANY') THEN
                sql_select_part := sql_select_part||', '||cal_ref.NUM_G_CUST_SEGMENT;
                final_sql := final_sql||cal_ref.NUM_G_CUST_SEGMENT||', ';
            ELSE
                sql_select_part := sql_select_part||', '' ''';
            END IF;     
            IF(cal_ref.NUM_G_DUMMY1 != ' ' and cal_ref.NUM_G_DUMMY1 != 'ANY') THEN
                final_sql := final_sql||cal_ref.NUM_G_DUMMY1||', ';
            END IF;
            IF(cal_ref.NUM_G_DUMMY2 != ' ' and cal_ref.NUM_G_DUMMY2 != 'ANY') THEN
                final_sql := final_sql||cal_ref.NUM_G_DUMMY2||', ';
            END IF;     
            
            final_sql := sql_select_part||' FROM $TARGET_DB.PREORDER_REG_SUMM_DETAILS WHERE 1=1'||REGEXP_REPLACE(final_sql,', \$','');
            
        ELSE
            final_sql := 'SELECT a.KEY_GROUP,a.PURPOSE,a.SALESNATURE,a.SALESNATURE_ORDER1,
                                 a.SALESNATURE_ORDER2,a.ORDER_DATE,a.PROD_CD,a.SERIES,a.PRODUCT_NATURE,
                                 a.COLOR,a.CUST_NATURE,a.PROD_TYPE,a.HSO_DESC,a.CUST_SEGMENT,
                                 a.PROD_CD_ORDER1,a.PROD_CD_ORDER2,a.CUST_NATURE_ORDER,a.PROD_TYPE_ORDER,
                                 a.HSO_DESC_ORDER,a.CUST_SEGMENT_ORDER,
                                 a.TOTAL '||cal_ref.FORMULA_OP||' b.TOTAL as TOTAL
                            FROM $TARGET_DB2.PREORDER_SUMMARY a
                            LEFT JOIN $TARGET_DB2.PREORDER_SUMMARY b ON b.ID = '''||cal_ref.FORMULA_OBJ2||''' 
                                  AND a.Prod_CD = b.Prod_CD AND a.SERIES = b.SERIES 
                                  AND a.PRODUCT_NATURE = b.PRODUCT_NATURE AND a.COLOR = b.COLOR
                                  AND a.CUST_NATURE = b.CUST_NATURE AND a.PROD_TYPE = b.PROD_TYPE
                                  AND a.HSO_DESC = b.HSO_DESC AND a.CUST_SEGMENT = b.CUST_SEGMENT
                           WHERE a.ID ='''||cal_ref.FORMULA_OBJ1||'''';
        END IF;
        
        OPEN cur1 FOR final_sql;
        LOOP
            --detemine whether to division formula
            IF( cal_ref.FORMULA_FLG = 'N' ) THEN
                FETCH cur1 INTO target_tbl.PROD_CD_ORDER1,target_tbl.PROD_CD_ORDER2,
                                target_tbl.CUST_NATURE_ORDER,target_tbl.PROD_TYPE_ORDER,
                                target_tbl.HSO_DESC_ORDER,target_tbl.CUST_SEGMENT_ORDER,
                                target_tbl.TOTAL,target_tbl.ORDER_DATE, target_tbl.PROD_CD, 
                                target_tbl.SERIES, target_tbl.PRODUCT_NATURE, target_tbl.COLOR,
                                target_tbl.CUST_NATURE, target_tbl.PROD_TYPE, target_tbl.HSO_DESC, 
                                target_tbl.CUST_SEGMENT;
            ELSE
                FETCH cur1 INTO cal_ref.KEY_GROUP,cal_ref.PURPOSE,cal_ref.SALESNATURE,
                                cal_ref.DISPLAYORDER1,cal_ref.DISPLAYORDER2,
                                target_tbl.ORDER_DATE, target_tbl.PROD_CD, 
                                target_tbl.SERIES, target_tbl.PRODUCT_NATURE, target_tbl.COLOR,
                                target_tbl.CUST_NATURE, target_tbl.PROD_TYPE, target_tbl.HSO_DESC, 
                                target_tbl.CUST_SEGMENT,target_tbl.PROD_CD_ORDER1,target_tbl.PROD_CD_ORDER2,
                                target_tbl.CUST_NATURE_ORDER,target_tbl.PROD_TYPE_ORDER,
                                target_tbl.HSO_DESC_ORDER,target_tbl.CUST_SEGMENT_ORDER,
                                target_tbl.TOTAL;
            END IF;
            
            EXIT WHEN cur1%NOTFOUND;
            INSERT INTO $TARGET_DB2.PREORDER_SUMMARY (
                ID,KEY_GROUP,PURPOSE,SALESNATURE,SALESNATURE_ORDER1,SALESNATURE_ORDER2,ORDER_DATE,
                PROD_CD,SERIES,PRODUCT_NATURE,COLOR,CUST_NATURE,PROD_TYPE,HSO_DESC,CUST_SEGMENT,
                PROD_CD_ORDER1,PROD_CD_ORDER2,CUST_NATURE_ORDER,PROD_TYPE_ORDER,HSO_DESC_ORDER,
                CUST_SEGMENT_ORDER,TOTAL
            )VALUES(
                cal_ref.ID,cal_ref.KEY_GROUP,cal_ref.PURPOSE,cal_ref.SALESNATURE,cal_ref.DISPLAYORDER1,cal_ref.DISPLAYORDER2,
                target_tbl.ORDER_DATE,target_tbl.PROD_CD,target_tbl.SERIES,target_tbl.PRODUCT_NATURE,target_tbl.COLOR,
                target_tbl.CUST_NATURE,target_tbl.PROD_TYPE,target_tbl.HSO_DESC,target_tbl.CUST_SEGMENT,target_tbl.PROD_CD_ORDER1,
                target_tbl.PROD_CD_ORDER2,target_tbl.CUST_NATURE_ORDER,target_tbl.PROD_TYPE_ORDER,target_tbl.HSO_DESC_ORDER,
                target_tbl.CUST_SEGMENT_ORDER,target_tbl.TOTAL
            );
            
            v_cnt := v_cnt+1;
            IF(mod(v_cnt,5000) = 0) THEN
               commit;
            END IF;
        END LOOP;
        CLOSE cur1;
    END LOOP;
    commit;
EXCEPTION WHEN OTHERS THEN
    dbms_output.put_line('SQLCODE:' || SQLCODE);
    dbms_output.put_line('SQLERRM:' || SQLERRM);
    raise_application_error(-20001,'Error - '||SQLCODE||' -Messge '||SQLERRM);
    ROLLBACK;
END;

/
exit;

ENDOFINPUT

    close(SQLPLUS);
    my $RET_CODE = $? >> 8;
    if ($RET_CODE != 0){
        return 1;
    }else{
        return 0;
    }
}


#We need to have variable input for the program to start
if ($#ARGV < 0){
    print("Syntax : perl <Script Name> <System Name>_<Job Name>_<TXDATE>.dir>\n");
    print("Example: perl b_preorder_summary0010.pl ADW_B_PREORDER_SUMMARY_20190829.dir\n");
    exit(1);
}

#Call the function we want to run
open(STDERR, ">&STDOUT");

my $pre = etlvar::preProcess($ARGV[0]);
my $rc = etlvar::getTXDate($MASTER_TABLE);
my $ret = initParam();
if ($ret == 0){
	$ret = runSQLPLUS();
}
if ($ret != 0){
    exit 2;
}

my $post = etlvar::postProcess();

exit($ret);

