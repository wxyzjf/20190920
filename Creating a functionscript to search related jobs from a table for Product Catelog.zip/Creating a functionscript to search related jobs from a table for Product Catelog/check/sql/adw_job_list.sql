set head off
set verify off
set trimspool on
set newpage 0
set pagesize 0
set lines 1500
set termout off
set serveroutput off
set feedback off
set echo off
set trimout on
set colsep |
spool '&1'

select etl_system||'|'||etl_job from prd_etl.etl_job where enable =1 order by etl_system,etl_job;

spool off

quit;
