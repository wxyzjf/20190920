set head off
set verify off
set trimspool on
set newpage 0
set pagesize 0
set lines 1500
set termout off
set serveroutput off
set feedback off
set echo off
set trimout on
set colsep |
spool '&1'

Select etl_system||'|'||etl_job||'|'||stream_system||'|'||stream_job 
    from prd_etl.ETL_JOB_stream
    where enable =1;

spool off

quit;
