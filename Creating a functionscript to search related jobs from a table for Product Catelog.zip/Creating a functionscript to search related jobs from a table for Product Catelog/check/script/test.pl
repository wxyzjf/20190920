#$vline="\$TARGET_TABLE=\"TBL1_1\";";
#$vline=~/\$TARGET_TABLE="?(\w+)"?/i;
$v_line="INSERT/*+APPENDPARALLEL()*/INTO\${etlvar::ADWDB}.U_DEL_NET_CHURN_RA_PL_MON (dksjfls)";

$v_tmpstr=$v_line;

$v_pos=index(lc($v_tmpstr),lc("into"));
$v_tmpstr=substr($v_tmpstr,$v_pos+4);

$v_pos=index(lc($v_tmpstr),lc("."));
$v_tmpsch=substr($v_tmpstr,1,$v_pos - 1);
$v_tmpstr=substr($v_tmpstr,$v_pos+1);

$v_tmpstr =~ /^(\w+)/;
$v_tmptbl = $1;


print "--->".$v_tmpsch."---".$v_tmptbl."\n";


sub callperl{
    #my $res = system('perl ./adw_gen_job_to_tbl.pl > ../log/test.log');
    #print "$res \n";
    my $datetime = `date +'%Y%m%d%H%M%S'`;
    $datetime = substr($datetime,0,-1);
    print substr("123_345",0,index("123_345","_"));
    print substr("123_345",index("123_345","_")+1);
    print "\n";
}

callperl();


