#use strict;
#use warnings;

use DBI;
use Date::Manip;

#############
## Set env
## 
#############
#
my $base_path = "/home/adwbat/CHK_JOB_DEP";
my $p_job_path = $base_path."/APP";

my $datetime = `date +'%Y%m%d%H%M%S'`;
$datetime = substr($datetime,0,-1);
my $date = `date +'%Y%m%d'`;
$date = substr($date,0,-1);
my $of_out_job_list=$base_path."/tmp/out_job_list.txt";
my $of_job_target_tbl=$base_path."/output/out_job_target_tbl.txt";
my $adw_gen_job_to_tbl_log = $base_path."/log/adw_gen_job_to_tbl_".$datetime.".log";

my $loader_ctl_file = $base_path."/sql/adw_job_target_tbl.ctl";
my $load_adw_job_target_tbl_log = $base_path."/log/load_adw_job_target_tbl_".$date.".log";
my $load_adw_job_target_tbl_bad = $base_path."/log/load_adw_job_target_tbl_".$date.".bad";
my $load_adw_job_target_tbl_dis = $base_path."/log/load_adw_job_target_tbl_".$date.".dis";

#
#
#
my $dbh = DBI->connect("dbi:Oracle:$ENV{'TDPID'}", "", "", {RaiseError=>1, AutoCommit=> 0}) or die "$DBI::errstr\n"; 


sub refresh {
    my $res = system("perl $base_path/script/adw_gen_job_to_tbl.pl &> $adw_gen_job_to_tbl_log");
    if( $res != 0 ) {
        #print "Error : refresh Job Target Table fail! please check log :".$adw_gen_job_to_tbl_log."\n";
        die "Error : refresh Job Target Table fail! please check log :".$adw_gen_job_to_tbl_log."\n";
    } else {
        print "loading data into DB...";
        my $sqlldr = "sqlldr \/\@\$TDPID " .
                      " control=".$loader_ctl_file .
                      " data=".$of_job_target_tbl .
                      " log=".$load_adw_job_target_tbl_log .
                      " bad=".$load_adw_job_target_tbl_bad .
                      " discard=".$load_adw_job_target_tbl_dis .
                      " errors=1 " .
                      " direct=true";
        $res = system($sqlldr);
        $res = $res >> 8;
        if( $res != 0 && $res != 2 ) {
            #print "Error : load data into table ADW_JOB_TARGET_TBL fail! please check log :".$load_adw_job_target_tbl_log."\n";
            die "Error : load data into table ADW_JOB_TARGET_TBL fail! \n";
        }else{
            print "refresh successfully.\n";
            print "log: $load_adw_job_target_tbl_log \n";
        }
    }
}


sub search {
    ($v_sys,$v_job)=@_;
    my $of_out_related_file_list = $base_path."/output/${v_sys}_${v_job}.txt";
    open(FH_OUTPUT,">$of_out_related_file_list") or die $!;
    print "geting job stream...\n";
    my $sql = "select a.STREAM_SYSTEM,
                     a.STREAM_JOB,
                     b.TARGET_DB, 
                     b.TARGET_TBL
                from (
                        select  t.stream_system
                                ,t.stream_job
                        from  prd_etl.etl_job_stream t   
                        start with etl_system='${v_sys}' and etl_job='${v_job}'
                        connect by prior stream_system = etl_system and prior stream_job= etl_job
                        union all
                        select '${v_sys}','${v_job}' from dual
                     ) a
           left join MIG_ADW.ADW_JOB_TARGET_TBL b 
                  on a.STREAM_SYSTEM = b.STREAM_SYSTEM and a.STREAM_JOB = b.STREAM_JOB
               where TARGET_TBL is not null";
    my $datastmt  = $dbh->prepare($sql) or die "Can't prepare SQL statement $DBI::errstr\n";
    $datastmt->execute;
    print "geting related perl file...\n";
    while (my @fld = $datastmt->fetchrow_array) {
        open(FH_JOB,"find ${p_job_path}/*/*/bin -maxdepth 1 -name \"*.pl\"|xargs egrep -i -e \"\\.@fld[3](;|\$|[[:space:]]+)\" |cut -d\":\" -f1|sort|uniq|");
        while($v_line = <FH_JOB>){
            print FH_OUTPUT "@fld[0]|@fld[1]|@fld[2].@fld[3]|$v_line"."\n";
            print "@fld[0]|@fld[1]|@fld[2].@fld[3]|$v_line"."\n";
        }
	}
    $datastmt->finish;
    close(FH_OUTPUT);
    print "search successfully.\n";
    print "output file : ${of_out_related_file_list} \n";
}

if ($#ARGV < 0){
    print("Syntax : perl main.pl [refresh|search] jobSystem.jobname\n");
    exit(1);
}

if( $ARGV[0] eq "refresh" ) {
    print "start refresh...\n";
    refresh();
}elsif( $ARGV[0] eq "search" ){
    if($#ARGV < 1){
        die "Syntax : missing job name";
    }
    print "start search...\n";
    my $sys = substr($ARGV[1],0,index($ARGV[1],"."));
    my $job = substr($ARGV[1],index($ARGV[1],".")+1);
    search($sys,$job);
}



