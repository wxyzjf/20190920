#use strict;
#use warnings;

use DBI;
use Date::Manip;

#############
## Set env
## 
#############
#
my $base_path = "/home/adwbat/CHK_JOB_DEP";
my $p_job_path = $base_path."/APP";


#my $p_in_file = $ARGV[0];
#my $p_out_file = $ARGV[1];
my $p_delimiter ="\|";

my $of_out_job_list=$base_path."/tmp/out_job_list.txt";
my $of_job_target_tbl=$base_path."/output/out_job_target_tbl.txt";
my @ary_job_target_tbl;

#
#
#
my $dbh = DBI->connect("dbi:Oracle:$ENV{'TDPID'}", "", "", {RaiseError=>1, AutoCommit=> 0}) or die "$DBI::errstr\n"; 



sub f_err{
	my $errmsg=shift;
	print "===> ERROR : ".$errmsg."\n";
	die $errmsg;
}
sub f_msg{
	my $p_msg=shift;
	print "===> MESSAGE : ".$p_msg."\n";
}
sub test { 
	my $sql = "SELECT 1 
       		from dual";
	my $datastmt  = $dbh->prepare($sql) or die "Can't prepare SQL statement $DBI::errstr\n";
	$datastmt->execute;
	while (my @fld = $datastmt->fetchrow_array) {
		print $fld[0];
	}
	$datastmt->finish;
}
sub f_to_resfile{
	my $v_msg=shift;	
	print FH_RES $v_msg."\n";
}

sub f_unload_joblist{ 
	open (FH_JOB,">$of_out_job_list");
	my $sql = "select etl_system||'|'||etl_job from prd_etl.etl_job where enable =1 order by etl_system,etl_job";
	my $datastmt  = $dbh->prepare($sql) or die "Can't prepare SQL statement $DBI::errstr\n";
	$datastmt->execute;
	while (my @fld = $datastmt->fetchrow_array) {
		print FH_JOB $fld[0]."\n";
	}
	$datastmt->finish;
	close(FH_JOB);
}
sub f_analyse_target_tbl {
	($v_sys,$v_job)=@_;
	$v_cnt = 0 ;
	$v_found_tbl=0;
	f_msg "[ Analyse Target Table of Job - $v_sys:$v_job - ]";
	f_msg "";
	if (!( -e "${p_job_path}/${v_sys}/${v_job}/bin")){
		f_msg "--->!!!Path not found $v_sys $v_job";
		return;
	}	
	open (FH_CHK,"find ${p_job_path}/${v_sys}/${v_job}/bin -maxdepth 1  -name \"*pl\"|sort|xargs cat|");

	while($v_line = <FH_CHK>){
		chomp $v_line;
		#### replace space in line ####
		$v_line=~ s/(\s|\d)+//g;


		#### skip remark line ####
		if ( $v_line =~ /^(#|--)/ ) {
			next;
		}

		if ( index($v_line,"TARGET_DB=")>0){
			#####sample :my $TARGET_DB="$etlvar::ADWDB";#######
			$v_tmpstr = substr($v_line,index($v_line,"TARGET_DB"));
			$v_pos = index($v_tmpstr,"=");
			$v_tmpstr = substr($v_tmpstr,$v_pos+1);
			$v_pos = index($v_tmpstr,";");
			$v_target_db =  substr($v_tmpstr,0,$v_pos);
			$v_target_db =~ s/("|\$)//g;
			$v_target_db = uc($v_target_db);
		 	if ($v_target_db =~ /ETLVAR::ADWDB/ ) {
                                $v_target_db = "PRD_ADW";
                        }elsif($v_target_db =~ /ETLVAR::ADWVW/){
                                $v_target_db = "PRD_ADW_VW";
                        }elsif($v_target_db =~ /ETLVAR::BIZDB/){
                                $v_target_db = "PRD_BIZ_SUMM";
                        }elsif($v_target_db =~ /ETLVAR::BIZVW/){
                                $v_target_db ="PRD_BIZ_SUMM_VW";
                        }elsif($v_target_db =~ /ETLVAR::TMPDB/){
                                $v_target_db ="PRD_TMP";
                        }elsif($v_target_db =~ /ETLVAR::MIGDB/){
                                $v_target_db ="MIG_ADW";
                        }else{
                                $v_target_db = $v_target_db;
                        }
		}
		if ( index($v_line,"TARGET_TABLE=")>0){
			###### sample :my$TARGET_TABLE="NSP_BILL_SERV_REF";######
			$v_line =~ /TARGET_TABLE="?(\w+)"?/;
			$v_target_tbl = $1;
		}
		if ( index($v_line,"etlvar::runGenScript") > 0 ){
			if ( $v_target_db =~ /PRD_TMP|MIG_ADW/ ){
				f_msg "--->Skip runGenscript Tmp Table  Insert sql with $v_target_db $v_targettbl ";
			}else{
				f_msg "---Found runGenScript with [$v_target_db-$v_target_tbl]";
				f_to_resfile "${v_sys}|${v_job}|${v_target_db}|${v_target_tbl}";
				$v_found_tbl=1;
			}
		}

	#### use line_start for avoid insert at first word and index return 0 ###
		if (( index(lc("line_start:".$v_line),lc("insert")) > 0) && (index(lc($v_line),lc("into")) > 0 )){
			####### Sample : INSERT/*+APPENDPARALLEL()*/INTO${etlvar::ADWDB}.U_DEL_NET_CHURN_RA_PL_MON ######
			$v_tmpstr=$v_line;

			$v_pos=index(lc($v_tmpstr),lc("into"));
			$v_tmpstr=substr($v_tmpstr,$v_pos+4);

			$v_pos=index(lc($v_tmpstr),lc("."));
			$v_tmpsch=substr($v_tmpstr,0,$v_pos );
			$v_tmpstr=substr($v_tmpstr,$v_pos+1);

			$v_tmpstr =~ /(\w+)/;
			$v_tmptbl = uc($1);

			##########Override the schema to real #########
			$v_tmpsch=uc($v_tmpsch);
			if ($v_tmpsch =~ /ETLVAR::ADWDB/ ) {
				$v_tmpsch="PRD_ADW";
			}elsif($v_tmpsch =~ /ETLVAR::ADWVW/){
				$v_tmpsch="PRD_ADW_VW";
			}elsif($v_tmpsch =~ /ETLVAR::BIZDB/){
				$v_tmpsch="PRD_BIZ_SUMM";
			}elsif($v_tmpsch =~ /ETLVAR::BIZVW/){
				$v_tmpsch="PRD_BIZ_SUMM_VW";
			}elsif($v_tmpsch =~ /ETLVAR::TMPDB/){
				$v_tmpsch="PRD_TMP";
                        }elsif($v_tmpsch =~ /ETLVAR::MIGDB/){
                                $v_tmpsch ="MIG_ADW";
			}else{
				$v_tmpsch=$v_tmpsch;
			}
			##########
			if ( $v_tmpsch =~ /PRD_TMP|MIG_ADW/ ){
				f_msg "--->Skip Tmp Table  Insert sql with $v_tmpsch $v_tmptbl ";
			}else{
				f_msg "---Found Insert sql with [$v_tmpsch-$v_tmptbl]";
				f_to_resfile "${v_sys}|${v_job}|${v_tmpsch}|${v_tmptbl}";
				$v_found_tbl=1;
			}
		}
		$v_cnt ++;
	}
	close(FH_CHK);
	if ($v_found_tbl ==0){
		f_msg "---Not Found Target table";
		f_to_resfile "${v_sys}|${v_job}||";
	}
	f_msg "";
	f_msg "";
}

sub main_func{
	# Check input file exist or not 
	if (!( -e $of_out_job_list )) {
		f_err "No input file found $of_out_job_list";
	}
	# Loop the input file and call checking function
	#
	##open(FH_JOBLIST,"grep B_NSP_BILL_SERV_REF $of_out_job_list|") or die $!;
	#
	open(FH_JOBLIST,"cat $of_out_job_list|") or die $!;
	open(FH_RES,">$of_job_target_tbl") or die $!;
	while($v_line = <FH_JOBLIST>){
		chomp $v_line;
		($v_sys,$v_job)= split (/\|/,$v_line);
		f_analyse_target_tbl($v_sys,$v_job);

	}
 
	close(FH_JOBLIST);
	close(FH_RES);
		
}












#############Main WorkFlow #######################
#f_unload_joblist();
main_func();
$dbh->disconnect;
