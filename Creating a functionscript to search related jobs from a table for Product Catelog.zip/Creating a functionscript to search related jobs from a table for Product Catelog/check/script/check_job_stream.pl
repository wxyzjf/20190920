use strict;
use warnings;

use DBI;
use Spreadsheet::WriteExcel;
use Date::Manip;

#############
## Set env
## 
#############
my $p_in_file = $ARGV[0];
my $p_out_file = $ARGV[1];
my $p_delimiter ="|";
#
#
#
my $dbh = DBI->connect("dbi:Oracle:$ENV{'TDPID'}", "", "", {RaiseError=>1, AutoCommit=> 0}) or die "$DBI::errstr\n"; 



sub f_err{
	my $errmsg=shift;
	print "===> ERROR : ".$errmsg."\n";
	die $errmsg;
}
sub f_msg{
	my $msg=shift;
	print "===> MESSAGE : ".$msg."\n";
}
sub test { 
	my $sql = "SELECT 1 
       		from dual";
	my $datastmt  = $dbh->prepare($sql) or die "Can't prepare SQL statement $DBI::errstr\n";
	$datastmt->execute;
	while (my @fld = $datastmt->fetchrow_array) {
		print $fld[0];
	}
	$datastmt->finish;
}

test();

sub f_chkjob  

sub main_func{

	# Check input file exist or not 
	#
	if (!( -e $p_in_file )) {
		f_errhdl "No input file found $p_in_file";
	}
	# Loop the input file and call checking function
	open(FH_JOBLIST, '<', $p_in_file) or die $!;
	while($v_line = <FH>){
		($v_sys,$v_job)= split $p_delimiter,$v_line;
		
	}
 
	close(FH);
		
}
main_func();
$dbh->disconnect;
